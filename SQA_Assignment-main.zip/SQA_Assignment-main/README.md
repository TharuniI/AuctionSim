# SQA Lab Assignment
## Description
Auction stimulator that allows users to: login, create/delete users, auction/purchase items, add/refund credit (depending on the type of user they are)

## Execution

## Front End Commands
#### Running Frontend
In terminal run "Make" <br>
After the object files are created run "./AuctionFrontEnd CurrentUserAccounts.txt CurrentItemList.txt DailyTransactionFile.txt"

#### Running the Tests
In  terminal run "./test.sh"

## Back End Commands
#### Running Backend
Change into directory /Back_end <br>
Run "python3 ./src/main.py" in terminal

#### Running the Tests
In  terminal run "python3 -m pytest -s --cov ./src" from the /Back_end folder.


## Key Information
#### Preset User Data 
| Username | Password  | User Type |  Auctioned Items  |  Purchased Items  |
| :------: | :-------: |:--------: |  :--------------: |  :--------------: |
| Tiranjan | food12345 |    SS     |  LenovoThinkPad   |                   |
| Parth_B  | food12345 |    FS     |  NikeAirForce     |  Apple            |
| Deepu    | food12345 |    BS     |                   |  LenovoThinkPad   |
| Tirthh   | food12345 |    AA     |  Apple            |  NikeAirForce     |

#### Transaction Types
Login, Logout, Create, Delete, Bid, Refund, Advertise, AddCredit, ViewAccounts, ViewItems, ResetPassword

## Contributors 
| Group Member Name |                  GitHub Username                  |
| :---------------- | :-----------------------------------------------: |
| Deepan Patel      |  [deepan-patel](https://github.com/deepan-patel)  |
| Tharuni Iranjan   |     [TharuniI](https://github.com/TharuniOTU)     |
| Tirth Patel       | [TirthPOnTechU](https://github.com/TirthPOnTechU) |
