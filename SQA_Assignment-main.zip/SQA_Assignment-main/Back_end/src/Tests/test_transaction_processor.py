import sys
import os
cwd = os.getcwd()
sys.path.append(cwd+"/src")

from User import User
from Item import Item
from TransactionProcessor import TransactionProcessor

test_currentAccountUsers = [
    User(username="Tiranjan_______",userType="SS",availableCredit="999999.00",password="ajj_,-./0"),
    User(username="Parth_B________",userType="FS",availableCredit="000010.01",password="ajj_,-./0"),
    User(username="Deepu__________",userType="BS",availableCredit="999999.00",password="ajj_,-./0"),
    User(username="Tirthh_________",userType="AA",availableCredit="999999.00",password="ajj_,-./0"),
    User(username="AM_BOB_________",userType="AM",availableCredit="999999.00",password="ajj_,-./0") 
]

test_currentAuctionItems = [
    Item(itemName="LenovoThinkPad___________",sellerName="Tiranjan_______",buyerName="Deepu__________",remainingDays="084",bid="2100.7"),
    Item(itemName="NikeAirForce_____________",sellerName="Parth_B________",buyerName="Tirthh_________",remainingDays="001",bid="090.05"),
    Item(itemName="Apple____________________",sellerName="Tirthh_________",buyerName="Parth_B________",remainingDays="100",bid="150.00")
]

#Populate transactions accordingly to the test
test_transactions = []

def test_sellersItemExist_unsuccessful():
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_itemName = "FourAirForce_____________"
    test_sellerName = "Tiranjan_______"
    assert test_transactionProcessor.sellersItemExist(test_sellerName,test_itemName) == False


def test_findItem_unsuccessful():
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_itemName = "FourAirForce_____________"
    assert test_transactionProcessor.findItem(test_itemName) == -1

def test_findUser_unsuccessful():
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_username = "Tiranxan_______"
    assert test_transactionProcessor.findUser(test_username) == -1

def test_ProcessAllTransaction():
    test_transactions.append("01_Vnirujan________SS_999999.00")
    test_transactions.append("02_Tirthh__________BS_999999.00")
    test_transactions.append("03_Orange____________________Tirthh__________100_100.00")
    test_transactions.append("04_NikeAirForce______________Parth_B_________Tirthh__________250.00")
    test_transactions.append("05_Parth_B_________Tiranjan________000020.00")
    test_transactions.append("06_Tiranjan________SS_000020.00")
    test_transactions.append("07_Deepu___________BS_999999.00_ajj_,-./1")
    
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    result = test_transactionProcessor.processAllTransactions()
    assert result == True

# Create User Tests
def test_createUser_successfull():
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_transaction_line_sucessfull = "01_VBirujan________SS_999999.00"
    assert test_transactionProcessor.ProcessCreate(test_transaction_line_sucessfull) == 1

def test_createUser_unsuccessfull():
    # when user tries to create a user with an exisitng username
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_transaction_line_unsucessfull = "01_Tiranjan________SS_999999.00"
    assert test_transactionProcessor.ProcessCreate(test_transaction_line_unsucessfull) == -1

# Delete User Test
def test_deleteUser_successfull():
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_transaction_line_sucessfull = "02_Tirthh__________BS_999999.00"
    assert test_transactionProcessor.ProcessDelete(test_transaction_line_sucessfull) == 1

def test_deleteUser_unsuccessfull():
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    # whne user tries to delete a username that dosent exist
    test_transaction_line_unsucessfull = "02_VBiruxxn________SS_999999.00"
    assert test_transactionProcessor.ProcessDelete(test_transaction_line_unsucessfull) == -1

# Advertise Tests
def test_advertise_successfull(): 
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_transaction_line_sucessfull = "03_Orange____________________Tirthh__________100_100.00"
    assert test_transactionProcessor.ProcessAdvertise(test_transaction_line_sucessfull) == 1

def test_advertise_unsuccessfull_rights():
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    # when user is buy-standard
    test_transaction_line_unsucessfull = "03_Orange____________________Deepu___________100_100.00"
    assert test_transactionProcessor.ProcessAdvertise(test_transaction_line_unsucessfull) == -1

def test_advertise_unsuccessfull_item():
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    # when user tries to make an item that already exists
    test_transaction_line_unsucessfull = "03_NikeAirForce______________Tirthh__________100_100.00"
    assert test_transactionProcessor.ProcessAdvertise(test_transaction_line_unsucessfull) == -1

def test_advertise_made_by_account_manager():
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    # when user tries to make an item that already exists
    test_transaction_line_unsucessfull = "03_Orange____________________AM_BOB_________100_105.00"
    assert test_transactionProcessor.ProcessAdvertise(test_transaction_line_unsucessfull) == -1


# Refund Tests
def test_refund_successfull(): 
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_transaction_line_sucessfull = "05_Parth_B_________Tiranjan________000020.00"
    assert test_transactionProcessor.ProcessRefund(test_transaction_line_sucessfull) == 1


def test_refund_unsuccessfull_value(): 
    # test when a refund is issued and the seller exceeds that amount
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_transaction_line_unsucessfull = "05_Parth_B_________Tiranjan________999999.99"
    assert test_transactionProcessor.ProcessRefund(test_transaction_line_unsucessfull) == -1

# Add Credit Tests
def test_addCredit_successfull(): 
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)

    test_transaction_line_sucessfull = "06_Tiranjan________SS_000020.00"
    assert test_transactionProcessor.ProcessAddCredit(test_transaction_line_sucessfull) == 1

def test_addCredit_unsuccessfull():
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    # test when username dosent exist
    test_transaction_line_unsucessfull = "06_Vnxrujan________SS_000020.00"
    assert test_transactionProcessor.ProcessAddCredit(test_transaction_line_unsucessfull) == -1

# Reset Password Tests
def test_resetPassword_successful():
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_transaction_line_sucessfull = "07_Deepu___________BS_999999.00_ajj_,-./1"
    assert test_transactionProcessor.ProcessResetPassword(test_transaction_line_sucessfull) == 1


def test_resetPassword_unsuccessfull():
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    # test when username dosent exist
    test_transaction_line_unsucessfull = "07_Vnxrujan________BS_999999.00_ajj_,-./1"
    assert test_transactionProcessor.ProcessResetPassword(test_transaction_line_unsucessfull) == -1