import pytest
from Item import Item
# --------- TESTING ITEM.PY -------------
#self, sellerName="null", buyerName="null", itemName="null", bid="null", remainingDays="null"

def test_setBid():
    test_item = Item("Tiranjan_______","Deepu__________","LenovoThinkPad___________","2100.7","068")
    test_item.setBid(2100.7,"Tirthh")
    assert test_item.getBuyerNameFormatted() == "Tirthh_________"
    assert test_item.getBidFormatted() == "2100.7"

def test_getItemFormatted():
    test_item = Item("Tiranjan_______","Deepu__________","LenovoThinkPad___________","2100.7","068")
    assert test_item.getItemFormatted() == "LenovoThinkPad___________"

def test_getItemName():
    test_item = Item("Tiranjan_______","Deepu__________","LenovoThinkPad___________","2100.7","068")
    assert test_item.getItemName() == "LenovoThinkPad"

def test_getSellerNameFormatted():
    test_item = Item("Tiranjan_______","Deepu__________","LenovoThinkPad___________","2100.7","068")
    assert test_item.getSellerNameFormatted() == "Tiranjan_______"

def test_getSellerName():
    test_item = Item("Tiranjan_______","Deepu__________","LenovoThinkPad___________","2100.7","068")
    assert test_item.getSellerName() == "Tiranjan"

def test_getBuyerNameFormatted():
    test_item = Item("Tiranjan_______","Deepu__________","LenovoThinkPad___________","2100.7","068")
    assert test_item.getBuyerNameFormatted() == "Deepu__________"

def test_getBuyerName():
    test_item = Item("Tiranjan_______","Deepu__________","LenovoThinkPad___________","2100.7","068")
    assert test_item.getBuyerName() == "Deepu"

def test_getBidFormatted():
    test_item = Item("Tiranjan_______","Deepu__________","LenovoThinkPad___________","2100.7","068")
    assert test_item.getBidFormatted() == "2100.7"

def test_getBid():
    test_item = Item("Tiranjan_______","Deepu__________","LenovoThinkPad___________","2100.7","068")
    assert test_item.getBid() == 2100.7

def test_getremainingDays():
    test_item = Item("Tiranjan_______","Deepu__________","LenovoThinkPad___________","2100.7","068")
    assert test_item.getremainingDays() == 68

def test_saveItemFormatted():
    test_item = Item("Tiranjan_______","Deepu__________","LenovoThinkPad___________","2100.7","068")
    assert test_item.saveItemFormatted() == "LenovoThinkPad____________Tiranjan________Deepu___________068_2100.7"

def test_repr():
    test_item = Item("Tiranjan_______","Deepu__________","LenovoThinkPad___________","2100.7","068")
    assert repr(test_item) == "SellerName:Tiranjan_______,BuyerName:Deepu__________,ItemName:LenovoThinkPad___________,Bid:2100.7,RemaininDays:068"