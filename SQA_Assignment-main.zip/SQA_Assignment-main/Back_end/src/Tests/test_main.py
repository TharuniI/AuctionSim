import sys
import os
cwd = os.getcwd()
sys.path.append(cwd+"/src")

import shutil
from main import main

def are_files_equal(file1_path, file2_path):
    with open(file1_path, 'r') as file1:
        with open(file2_path, 'r') as file2:
            return file1.read() == file2.read()

def test_main():
    # Copy file to new directory
    shutil.copy('CurrentItemList.txt', 'src/CopyOfCurrentItemList.txt.txt')
    shutil.copy('CurrentUserAccounts.txt', 'src/CopyOfCurrentUserAccounts.txt')
    main()

    isUserFilesEqual=are_files_equal("src/CopyOfCurrentUserAccounts.txt","CurrentUserAccounts.txt")
    isItemFilesEqual=are_files_equal('src/CopyOfCurrentItemList.txt.txt',"CurrentItemList.txt")

    isOnlyTransLineEnd=False
    with open("DailyTransactionFile.txt", 'r') as transFile:
        lines=transFile.readlines()
        if(len(lines)==1 and lines[0]=="00"):
            isOnlyTransLineEnd=True
    if(isOnlyTransLineEnd):
        assert(isUserFilesEqual==True and isItemFilesEqual==True)
    else:
        assert(isUserFilesEqual==False or isItemFilesEqual==False)