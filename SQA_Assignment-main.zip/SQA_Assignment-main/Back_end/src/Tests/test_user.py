import pytest
from User import User
# --------- TESTING USER.PY -------------

#self,username="null",userType="null",availableCredit="null",password="null")
def test_getUsernameFormatted():
    test_user = User("Tiranjan_______", "SS", "0999979", "0_ajj_,-./0")
    assert test_user.getUsernameFormatted() == "Tiranjan_______"

def test_getPassword():
    test_user = User("Tiranjan_______", "SS", "0999979", "0_ajj_,-./0")
    assert test_user.getPassword() == "0_ajj_,-./0"

def test_getType():
    test_user = User("Tiranjan_______", "SS", "0999979", "0_ajj_,-./0")
    assert test_user.getType() == "SS"

def test_getAvailableCredit():
    test_user = User("Tiranjan_______", "SS", "0999979", "0_ajj_,-./0")
    assert test_user.getAvailableCredit() == 999979.00 

def test_getUsername():
    test_user = User("Tiranjan_______", "SS", "0999979", "0_ajj_,-./0")
    assert test_user.getUsername() == "Tiranjan"
def test_setAvailableCredit():
    test_user = User("Tiranjan_______", "SS", "0999979", "0_ajj_,-./0")
    test_user.setAvailableCredit("0012345")
    assert test_user.getAvailableCredit() == 12345.0

def test_setPassword():
    test_user = User("Tiranjan_______", "SS", "0999979", "0_ajj_,-./0")
    test_user.setPassword("0_ajj_,-./1")
    assert test_user.getPassword() == "0_ajj_,-./1"

def test_hasEnoughCredit():
    test_user = User("Tiranjan_______", "SS", "0999979", "0_ajj_,-./0")
    assert test_user.hasEnoughCredit(20) == True

def test_saveUserFormatted():
    test_user = User("Tiranjan_______", "SS", "0999979", "0_ajj_,-./0")
    assert test_user.saveUserFormatted() == "Tiranjan________SS_0999979_0_ajj_,-./0" # make sure this matches

def test_chargeCredit():
    test_user = User("Tiranjan_______", "SS", "0999979", "0_ajj_,-./0")
    test_user.chargeCredit("100")
    assert test_user.getAvailableCredit() == 0999879.0

def test_addCredit():
    test_user = User("Tiranjan_______", "SS", "0999979", "0_ajj_,-./0")
    test_user.addCredit("10")
    assert test_user.getAvailableCredit() == 999989.0

def test_repr():
 test_user = User("Tiranjan_______", "SS", "0999979", "0_ajj_,-./0")    
 assert repr(test_user) == "Username:Tiranjan_______,type:SS,availableCredit:0999979,password:0_ajj_,-./0"