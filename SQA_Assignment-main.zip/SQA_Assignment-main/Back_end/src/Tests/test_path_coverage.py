"""
Path coverage was checked for ProcessBid Method of TransactionProcessor
"""
import sys
import os
cwd = os.getcwd()
sys.path.append(cwd+"/src")

from User import User
from Item import Item
from TransactionProcessor import TransactionProcessor

test_currentAccountUsers = [
    User(username="Tiranjan_______",userType="SS",availableCredit="999999.00",password="ajj_,-./0"),
    User(username="Parth_B________",userType="FS",availableCredit="000010.01",password="ajj_,-./0"),
    User(username="Deepu__________",userType="BS",availableCredit="999999.00",password="ajj_,-./0"),
    User(username="Tirthh_________",userType="AA",availableCredit="999999.00",password="ajj_,-./0"),
    User(username="AM_BOB_________",userType="AM",availableCredit="999999.00",password="ajj_,-./0") 
]

test_currentAuctionItems = [
    Item(itemName="LenovoThinkPad___________",sellerName="Tiranjan_______",buyerName="Deepu__________",remainingDays="084",bid="2100.7"),
    Item(itemName="NikeAirForce_____________",sellerName="Parth_B________",buyerName="Tirthh_________",remainingDays="001",bid="090.05"),
    Item(itemName="Apple____________________",sellerName="Tirthh_________",buyerName="Parth_B________",remainingDays="100",bid="150.00")
]

#Populate transactions accordingly to the test
test_transactions = []

# Bid Tests
def test_bid_successfull_path(): 
    #Testing the successfull path so bid is placed successfully 
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_transaction_line_sucessfull = "04_NikeAirForce______________Parth_B_________Tirthh__________250.00"
    assert test_transactionProcessor.ProcessBid(test_transaction_line_sucessfull) == 1

def test_bid_unsuccessfull_path1():
    # tests when bid value is not higher than 5%
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_transaction_line_unsucessfull = "04_NikeAirForce______________Parth_B_________Tirthh__________010.00"
    assert test_transactionProcessor.ProcessBid(test_transaction_line_unsucessfull) == -1

def test_bid_unsuccessfull_path2():
    # Seller is not selling this item
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_transaction_line_unsucessfull = "04_NikeAirForce______________Tirthh__________Parth_B_________250.00"
    assert test_transactionProcessor.ProcessBid(test_transaction_line_unsucessfull) == -1

def test_bid_unsuccessfull_path3():
    # if buyer exist check if they are a valid user type
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_transaction_line_unsucessfull = "04_NikeAirForce______________Parth_B_________Tiranjan________250.00"
    assert test_transactionProcessor.ProcessBid(test_transaction_line_unsucessfull) == -1

def test_bid_unsuccessfull_path4():
    # Checking if seller does not exists
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_transaction_line_unsucessfull = "04_NikeAirForce______________Tiranj9n________Tirthh__________250.00"
                                         
    assert test_transactionProcessor.ProcessBid(test_transaction_line_unsucessfull) == -1

def test_bid_unsuccessfull_path5(): 
    # Checking if buyer does not exists
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_transaction_line_unsucessfull = "04_NikeAirForce______________Parth_B_________Tirtxh__________250.00"
    assert test_transactionProcessor.ProcessBid(test_transaction_line_unsucessfull) == -1

def test_bid_unsuccessfull_path6(): 
    # Checking if seller exist does not have the correct type
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_transaction_line_unsucessfull = "04_NikeAirForce______________Deepu___________Tirthh__________250.00"
    assert test_transactionProcessor.ProcessBid(test_transaction_line_unsucessfull) == -1

def test_bid_unsuccessfull_path7(): 
    # Checking if AM can place a bid
    test_transactionProcessor=TransactionProcessor(test_currentAccountUsers,test_currentAuctionItems,test_transactions)
    test_transaction_line_unsucessfull = "04_NikeAirForce______________Parth_B_________AM_BOB_________250.00"
    assert test_transactionProcessor.ProcessBid(test_transaction_line_unsucessfull) == -1
