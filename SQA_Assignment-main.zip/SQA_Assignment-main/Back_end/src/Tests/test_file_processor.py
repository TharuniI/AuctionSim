import sys
import os
cwd = os.getcwd()
sys.path.append(cwd+"/src")

from User import User
from Item import Item
from FileProcessor import FileProcessor

def test_readDailyTransactionFile():
    processor=FileProcessor()
    processor.readDailyTransactionFile()
    numLines=None
    with open('DailyTransactionFile.txt', 'r') as file:
        numLines = len(file.readlines())
    
    assert (numLines-1)==len(processor.transactions)
    assert all(isinstance(transaction, str) for transaction in processor.transactions)

def test_readUsersFile():
    processor=FileProcessor()
    processor.readUsersFile()
    numLines=None
    with open('CurrentUserAccounts.txt', 'r') as file:
        numLines = len(file.readlines())
    
    assert (numLines-1)==len(processor.users)
    assert all(isinstance(user, User) for user in processor.users)

def test_readItemsFile():
    processor=FileProcessor()
    processor.readItemsFile()
    numLines=None
    with open('CurrentItemList.txt', 'r') as file:
        numLines = len(file.readlines())
    
    assert (numLines-1)==len(processor.items)
    assert all(isinstance(item, Item) for item in processor.items)

def test_writeUsersFile():
    processor=FileProcessor()
    userList=[]
    userList.append(User("Tiranjan_______", "SS", "0999979", "0_ajj_,-./0\n"))
    userList.append(User("Parth__________", "SS", "0999979", "0_ajj_,-./0\n"))
    processor.writeUsersFile(users=userList)

    numLines=None
    endLine=""
    with open("CurrentUserAccounts.txt","r") as file:
        lines=file.readlines()
        numLines=len(lines)
        endLine=lines[-1]
    
    assert numLines==3
    assert endLine=="END________________000000000_ajj_,-./0"


def test_writeItemsFile():
    processor=FileProcessor()
    itemList=[]
    itemList.append(Item("Tiranjan_______","Deepu__________","LenovoThinkPad___________","2100.7\n","068"))
    itemList.append(Item("Tiranjan_______","Deepu__________","LenovoThinkPad___________","2100.7\n","068"))
    processor.writeItemsFile(items=itemList)

    numLines=None
    endLine=""
    with open("CurrentItemList.txt","r") as file:
        lines=file.readlines()
        numLines=len(lines)
        endLine=lines[-1]
    
    assert numLines==3
    assert endLine=="END_________________________________________________________________"