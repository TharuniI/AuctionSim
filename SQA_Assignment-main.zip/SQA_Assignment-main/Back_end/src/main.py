from FileProcessor import FileProcessor
from TransactionProcessor import TransactionProcessor
"""
Main file that handles the Backend of our Auction simulator
Calls the necessary functions to update the useraccount and item files
"""

def main():
    fileProcessor=FileProcessor()
    fileProcessor.readUsersFile()
    fileProcessor.readItemsFile()
    fileProcessor.readDailyTransactionFile()

    transactionProcessor=TransactionProcessor(fileProcessor.users,fileProcessor.items,fileProcessor.transactions)
    transactionProcessor.processAllTransactions()
    fileProcessor.writeItemsFile(transactionProcessor.currentAuctionItems)
    fileProcessor.writeUsersFile(transactionProcessor.currentAccountUsers)

if __name__ == "__main__":
    main()