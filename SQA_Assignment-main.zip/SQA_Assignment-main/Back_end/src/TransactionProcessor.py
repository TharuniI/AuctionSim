from User import *
from Item import *

"""
TransactionProcesser is the Backend that processes lines from Daily Transaction File
Depending on the code number, a different set of actions occur (ex. code 01 = Create)
"""
#Length defined for backend processing
transactionCodeLength = 2 #length of character for transaction code
usernameLength = 15
userTypeLength = 2
itemNameLength = 25
passwordLength = 9
numericValueLength = 9
dayLength = 3
    
class TransactionProcessor:

    def __init__(self,currentAccountUsers,currentAuctionItems,transactions):
        self.currentAccountUsers = currentAccountUsers
        self.currentAuctionItems = currentAuctionItems
        self.transactions = transactions

    #Main processor function that applies each
    def processAllTransactions(self):
        isSuccessful=True
        for transaction in self.transactions:
            results=None
            transCode=transaction[:2]
            if(transCode=="01"):
                results=self.ProcessCreate(transaction)
            elif(transCode=="02"):
                results=self.ProcessDelete(transaction)
            elif(transCode=="03"):
                results=self.ProcessAdvertise(transaction)
            elif(transCode=="04"):
                results=self.ProcessBid(transaction)
            elif(transCode=="05"):
                results=self.ProcessRefund(transaction)
            elif(transCode=="06"):
                results=self.ProcessAddCredit(transaction)
            elif(transCode=="07"):
                results=self.ProcessResetPassword(transaction)
            
        return isSuccessful

    # Checkers - checks if a certain Process is valid #
    # checks if the specifc user has rights to peform a specifc action
    def hasPrivellege(self,username,privellege_type):
        if(self.checkUserExist(username)):
            user_index = self.findUser(username)
            return (self.currentAccountUsers[user_index].getType() == privellege_type)
        else:   
            return False
    # checks if the user exists in the file        
    def checkUserExist(self,curr_username):
        for user in self.currentAccountUsers:
            if user.username == curr_username:
                return True
        return False
    # checks if an item already exists in the items file
    def checkItemExist(self,curr_item_name):
        for item in self.currentAuctionItems:
            if item.itemName == curr_item_name:
                return True
        return False
    # for a specifc user, check if they are selling an item
    def sellersItemExist(self,sellerName,itemName):
        if(self.checkItemExist(itemName)):
            item_index = self.findItem(itemName)
            return (self.currentAuctionItems[item_index].getSellerNameFormatted() == sellerName)
        else:
            return False
            
    # Finders - finds a specifc thing #
    # if an item exits, find its index in the items file            
    def findItem(self,curr_item_name):
        for index in range(len(self.currentAuctionItems)):
            if(self.currentAuctionItems[index].itemName == curr_item_name):
                return index
        return -1
    # if user gets, return its index in the user file
    def findUser(self,curr_username):
        for index in range(len(self.currentAccountUsers)):
            if(self.currentAccountUsers[index].username == curr_username):
                return index
        return -1

    # Mutators #
    def addItem(self,newUser):
        self.currentAuctionItems.append(newUser)

    def addUser(self,newUser):
        self.currentAccountUsers.append(newUser)
    

    # Processors - peforms each transaction type #
    """
    Each transaction should follow this validation logic:
          - valid inputs for any users or items 
          - if no problems with inputs then process functionality as expected
          - else error a log message
    """ 

    #01 - Create
    def ProcessCreate(self, transactionLine):
        print("Processing transaction: {}".format(transactionLine))
        # transaction code --> username --> type --> available credit --> password
        # variables saved from the transaction line
        
        usernameIndex = transactionCodeLength + 1
        typeIndex = usernameIndex + usernameLength + 1
        creditIndex = typeIndex + userTypeLength + 1
        passwordIndex = creditIndex + numericValueLength + 1

        username = transactionLine[usernameIndex:typeIndex-1]
        userType = transactionLine[typeIndex:creditIndex-1]
        defaultCredit = transactionLine[creditIndex:passwordIndex-1]
        encryptedPassword = transactionLine[passwordIndex:]
        
        
        # Check if this user already exists, if not add new user to user list
        if(not self.checkUserExist(username)):
            newUser = User(username,userType,defaultCredit,encryptedPassword)
            self.addUser(newUser)
            print("User <{}> added succesfully".format(username))
            return 1
        else:
            print("EU1 Error: Username <{}> already exists..".format(username))
            return -1
         

    #02 - Delete
    def ProcessDelete(self, transactionLine):

        #Reading the transaction for the the specific variables
        print("Processing transaction: {}".format(transactionLine))
        sellerNameIndex = transactionCodeLength + 1
        sellerName = transactionLine[sellerNameIndex:sellerNameIndex+usernameLength]
        print(len(sellerName))
        doesExist=self.checkUserExist(sellerName)
        if(doesExist):
            #If used exist contnue with deleting thier information
            
            #Deletes user from currentAccountUsers
            self.currentAccountUsers=list(filter(lambda user: (user.getUsernameFormatted() != sellerName), self.currentAccountUsers))
            #Deletes all items associate with the user as well 
            self.currentAuctionItems=list(filter(lambda item: (item.getSellerNameFormatted() != sellerName), self.currentAuctionItems))
            return 1
        else:
            print("EU1 Error: Username <{}> does not exist..".format(sellerName))
            return -1

    #03 - Advertise 
    def ProcessAdvertise(self, transactionLine):
        print("Processing transaction: {}".format(transactionLine))
        # transaction code --> itemname --> sellername --> remainingDays --> bid
        # variables saved from the transaction line
        itemNameIndex = transactionCodeLength + 1
        sellerNameIndex = itemNameIndex + itemNameLength + 1
        daysIndex = sellerNameIndex + usernameLength + 1
        bidIndex = daysIndex + dayLength + 1
        
        itemName = transactionLine[itemNameIndex:sellerNameIndex-1]
        sellerName = transactionLine[sellerNameIndex:daysIndex-1]
        remainingDays = transactionLine[daysIndex:bidIndex-1]
        bid = transactionLine[bidIndex:]

        # check if user has the correct privellages 
        #Added extra check for account manager as well
        if (not self.hasPrivellege(sellerName, "BS") and not self.hasPrivellege(sellerName, "AM")  ):
            # check if the item already exists, or not
            if(self.checkUserExist(sellerName)):
                if (not self.checkItemExist(itemName)):
                    newItem = Item(sellerName, "null___________", itemName, bid, remainingDays)
                    self.addItem(newItem)
                    print("Item <{}> successfully created".format(itemName))
                    return 1
                else:
                    print("EI2 Error: Item <{}> already exists".format(itemName))
                    return -1
            else:
                print("EU1 Error: User <{}> does not exists".format(sellerName))
                return -1
        else:
            print("PU Error: User <{}> does not have rights to perform this transaction".format(sellerName))
            return -1
                
    #04 - Bid
    def ProcessBid(self, transactionLine):
        print("Processing transaction: {}".format(transactionLine))
        #transaction code --> item name --> seller name --> buyer name --> bid
        
        # variables saved from the transaction line
        itemNameIndex = transactionCodeLength + 1
        sellerNameIndex = itemNameIndex + itemNameLength + 1
        buyerNameIndex = sellerNameIndex + usernameLength + 1
        bidAmountIndex = buyerNameIndex + usernameLength + 1

        itemName = transactionLine[itemNameIndex:sellerNameIndex-1]
        sellerName = transactionLine[sellerNameIndex:buyerNameIndex-1]
        buyerName = transactionLine[buyerNameIndex:bidAmountIndex-1]
        bidAmount = transactionLine[bidAmountIndex:]

        if(self.checkUserExist(sellerName)):
            #if buyer exist check if they are a valid user type
            if((self.hasPrivellege(sellerName, "AA")) or (self.hasPrivellege(sellerName, "FS")) or (self.hasPrivellege(sellerName, "SS"))):
                if(self.checkUserExist(buyerName)):
                    #if seller exist check if they are type seller
                    if ((self.hasPrivellege(buyerName, "AA")) or (self.hasPrivellege(buyerName, "FS")) or (self.hasPrivellege(buyerName, "BS"))):
                        if(self.sellersItemExist(sellerName,itemName)):
                            #if all exist then update the bid amount and buyerName
                            item_index = self.findItem(itemName)

                            #finally check if bid is 5% higher 
                            if((self.currentAuctionItems[item_index].getBid() * 1.05) < (float(bidAmount))):
                                
                                self.currentAuctionItems[item_index].setBid(bidAmount,buyerName)
                                print("Bid successfully made to Item <{}>".format(itemName))
                                return 1
                            else:
                                print("VU Error: Bid amount is not higher than 5%")
                                return -1
                        else:
                            print("EI1 Error: Seller is not selling item {}".format(itemName))
                            return -1
                    else:
                        print("PU Error: Buyer <{}> does not have rights to perform this transaction".format(buyerName))
                        return -1
                else:
                    print("EU1 Error: Buyer <{}> does not exist".format(buyerName))
                    return -1
            else:
                print("PU Error: Seller <{}> does not have rights to perform this transaction".format(sellerName))
                return -1
        else:
            print("EU1 Error: Seller <{}> does not exist".format(sellerName))
            return -1
        
    #05 - Refund 
    def ProcessRefund(self, transactionLine):
        print("Processing transaction: {}".format(transactionLine))

        #Indexing the transaction line to get each information
        buyerNameIndex=transactionCodeLength+1
        sellerNameIndex = buyerNameIndex + usernameLength + 1
        refundAmountIndex=sellerNameIndex+usernameLength+1

        buyerName = transactionLine[buyerNameIndex:sellerNameIndex-1]
        sellerName = transactionLine[sellerNameIndex:refundAmountIndex-1]
        refundAmountStr = transactionLine[refundAmountIndex:]

        buyerObj=self.currentAccountUsers[self.findUser(buyerName)]
        sellerObj=self.currentAccountUsers[self.findUser(sellerName)]

        
        if(sellerObj.hasEnoughCredit(refundAmountStr)):
            sellerObj.chargeCredit(refundAmountStr)
            buyerObj.addCredit(refundAmountStr)
            print("Refund successfully processed")
            return 1
            
        else:
            print("Seller does not have enough credits to refund the given amount.")
            return -1
    
    #06 - Add Credit
    def ProcessAddCredit(self,transactionLine):
        print("Processing transaction: {}".format(transactionLine))
        
        # variables saved from transaction line, user type not needed
        usernameIndex =  transactionCodeLength + 1
        userTypeIndex = usernameIndex + usernameLength + 1
        creditValIndex = userTypeIndex + userTypeLength + 1

        username =  transactionLine[usernameIndex: userTypeIndex-1]
        creditVal = transactionLine[creditValIndex:]
        # check if the user exists before adding credit
        if(self.checkUserExist(username)):
            user_index = self.findUser(username)
            self.currentAccountUsers[user_index].addCredit(creditVal)
            print("Credit successfully added to User <{}>".format(username))
            return 1
        else:
            print("EU1 Error: Username <{}> does not exist".format(username))
            return -1
        

    #07 - ProcessReset
    def ProcessResetPassword(self,transactionLine):

        print("Processing transaction: {}".format(transactionLine))
        # variables saved from transaction line
        username_index = transactionCodeLength + 1
        user_type_index= username_index + usernameLength + 1
        user_credit_index = user_type_index + userTypeLength + 1
        new_password_index = user_credit_index + numericValueLength +1

        username = transactionLine[username_index:user_type_index-1]
        new_password = transactionLine[new_password_index:]

        # check if user exists before changing password
        if(self.checkUserExist(username)):
            user_index = self.findUser(username)
            self.currentAccountUsers[user_index].setPassword(new_password)
            print("Successfully reset password to User <{}>".format(username))
            return 1
        else:
            print("EU1 Error: Username <{}> does not exist".format(username))
            return -1
