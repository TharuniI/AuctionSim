"""
User Class: stores values associated with a user
Can access/mutate values with this class 
"""

class User:
    def __init__(self,username="null",userType="null",availableCredit="null",password="null"):
        self.username = username
        self.type = userType
        self.availableCredit = availableCredit
        self.password = password

    #Accessors
    def getUsernameFormatted(self):
        return self.username

    def getPassword(self):
        return self.password

    def getType(self):
        return self.type

    def getAvailableCredit(self):
        credit_format = self.availableCredit
        return float(credit_format)

    def getUsername(self):
        username_format = self.username
        count = len(username_format)-1

        while (username_format[count] == '_'):
            count -= 1

        username_unformat = username_format[0:count+1]
        username_unformat.replace('_',' ')

        return username_unformat

    #Mutator
    def setAvailableCredit(self,newAvailableCredit):
        self.availableCredit = str(newAvailableCredit)

    def setPassword(self,new_password):
        self.password = new_password

    #new_credit is string
    def addCredit(self,new_credit):
        newAvailableCredit = round(float(self.availableCredit) + float(new_credit),2)
        self.availableCredit = self.NumUnformatToFormat(newAvailableCredit,9)

    def chargeCredit(self,new_credit):
        newAvailableCredit = round(float(self.availableCredit) - float(new_credit),2)
        self.availableCredit = self.NumUnformatToFormat(newAvailableCredit,9)

    def hasEnoughCredit(self,expense):
        return (float(self.availableCredit) >= float(expense))

    def saveUserFormatted(self):
        return "{}_{}_{}_{}".format(self.username,self.type,self.availableCredit,self.password)

    #Converting methods
    def NumUnformatToFormat(self,x, completeLength):
        result = str(x)
        currentLength = len(result) 
        result = result[0:currentLength]
        zeros = ""

        for i in range(completeLength - currentLength): zeros += "0"

        return zeros + result

    #Print method
    def __repr__(self):
        return "Username:{},type:{},availableCredit:{},password:{}".format(self.username,self.type,self.availableCredit,self.password)

