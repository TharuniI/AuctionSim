from User import User
from Item import Item

class FileProcessor:
    # constructor
    def __init__(self):
        self.transactions = []
        self.users=[]
        self.items=[]
        self.dailyTransactionFilePath="DailyTransactionFile.txt"
        self.currentItemListFilePath="CurrentItemList.txt"
        self.currentUserAccountsFilePath="CurrentUserAccounts.txt"
        
 
    # a method reading transaction data file
    def readDailyTransactionFile(self):
        dailyTransactionFile = open(self.dailyTransactionFilePath, 'r')
        transactionsStr = dailyTransactionFile.readlines()
        #read each lines and exit when it reads an exit code
        for line in transactionsStr:
            if(line=="00"):
                break
            self.transactions.append(line)

    # a method reading user accounts file
    def readUsersFile(self):
        userAccountsFile = open(self.currentUserAccountsFilePath, 'r')
        usersStr = userAccountsFile.readlines()
        #read each lines and exit when it reads an exit code
        for line in usersStr:
            username=line[:15]
            if(not(username.startswith("END"))):
                userType=line[16:18]
                userCreditStr=line[19:28]
                userPassword=line[29:]
                #create new user object from the parsed user attributes
                self.users.append(User(username=username,userType=userType,availableCredit=userCreditStr,password=userPassword))

    # a method reading available items file
    def readItemsFile(self):
        itemsFile = open(self.currentItemListFilePath, 'r')
        itemsStr = itemsFile.readlines()
        #read each lines and exit when it reads an exit code
        for line in itemsStr:
            itemName=line[:25]
            if(not(itemName.startswith("END"))):
                seller=line[26:41]
                highestBidder=line[42:57]
                remainingDays=line[58:61]
                currentBid=line[62:]
                #create new item object from the parsed item attributes
                self.items.append(Item(itemName=itemName,sellerName=seller,buyerName=highestBidder,remainingDays=remainingDays,bid=currentBid))

    # a method writing new user accounts file
    def writeUsersFile(self,users):
        with open('CurrentUserAccounts.txt', 'w') as f:
            for user in users:
                f.write(user.saveUserFormatted())
            f.write("END________________000000000_ajj_,-./0")

    # a method writing new available items file
    def writeItemsFile(self,items):
        with open('CurrentItemList.txt', 'w') as f:
            for item in items:
                f.write(item.saveItemFormatted())
            f.write("END_________________________________________________________________")