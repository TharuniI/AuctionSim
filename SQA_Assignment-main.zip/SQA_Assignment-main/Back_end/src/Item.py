"""
Item Class: stores values associated with an item
Can access/mutate values with this class 
"""

class Item:
    def __init__(self, sellerName="null", buyerName="null", itemName="null", bid="null", remainingDays="null"):
        self.sellerName = sellerName
        self.buyerName = buyerName
        self.itemName = itemName
        self.bid = bid
        self.remainingDays = remainingDays

    # Mutators
    def convertFormattoUnformat(self, string):
        result = ""
        count = len(string) - 1

        while (string[count] == "_"): count-= 1

        result = string[0:count+1]
        result.replace("_", " ")

        return result

    def convertUnformattoFormat(self, string, completeLength):
        result = string
        result.replace(" ", "_")
        currentLength = len(result)

        for i in range(completeLength - currentLength): result += "_"

        return result
    
    def NumUnformatToFormat(self,x, completeLength):
        result = str(x)
        currentLength = len(result) 
        result = result[0:currentLength]
        zeros = ""

        for i in range(completeLength - currentLength): zeros += "0"

        return zeros + result
    
    def setBid(self, newBid, buyerName):
        self.buyerName = self.convertUnformattoFormat(buyerName, 15)
        self.bid = self.NumUnformatToFormat(newBid,6)

    
    # Acessors
    def getItemFormatted(self):
        return self.itemName

    def getItemName(self):
        return self.convertFormattoUnformat(self.itemName)

    def getSellerNameFormatted(self):
        return self.sellerName
    
    def getSellerName(self):
        return self.convertFormattoUnformat(self.sellerName)

    def getBuyerNameFormatted(self):
        return self.buyerName

    def getBuyerName(self):
        return self.convertFormattoUnformat(self.buyerName)

    def getBid(self):
        return float(self.bid)
    
    def getBidFormatted(self):
        return self.bid
    
    def getremainingDays(self):
        return int(self.remainingDays)

    def saveItemFormatted(self):
        return "{}_{}_{}_{}_{}".format(self.itemName,self.sellerName,self.buyerName,self.remainingDays,self.bid)

    def __repr__(self):
        return "SellerName:{},BuyerName:{},ItemName:{},Bid:{},RemaininDays:{}".format(self.sellerName,self.buyerName,self.itemName,self.bid, self.remainingDays)



    
