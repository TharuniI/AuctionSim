#!/bin/bash
# declare STRING variable
make clean
# print variable on a screen
make

echo "Running Tests..."
for rootTests in Tests/* ; do
    [ -L "${rootTests%/}" ] && continue
    for rootTest in $rootTests/* ; do
        [ -L "${rootTest%/}" ] && continue
        epochTime=$(date +%s)
        outputPath=$rootTest/Outputs/${epochTime}.txt
        failedOutputPath=$rootTest/Outputs/${epochTime}-ERROR.txt
        touch $outputPath
    
        ./AuctionFrontEnd CurrentUserAccounts.txt CurrentItemList.txt DailyTransactionFile.txt < $rootTest/Input.txt > $outputPath
        # ./AuctionFrontEnd CurrentUserAccounts.txt CurrentItemList.txt DailyTransactionFile.txt < $rootTest/Input.txt

        #compare output files
        outputDifference=$(diff $outputPath $rootTest/ExpectedOutcomeFiles/Output.txt)

        #compare DailyTransactionFiles
        DTFDifference=$(diff ./Back_end/DailyTransactionFile.txt $rootTest/ExpectedOutcomeFiles/DailyTransactionFile.txt)

        if [[ -z $outputDifference && -z $DTFDifference ]]; then
        # passed case
            echo -e "[\xE2\x9C\x94] - $rootTest"
        else
        # failed case
            echo -e "[\xE2\x9D\x8C] - $rootTest"
            cp ./Back_end/DailyTransactionFile.txt $rootTest/Outputs/${epochTime}_DailyTransactionFile-ERROR.txt

            # exit 1
        fi
        rm ./Back_end/DailyTransactionFile.txt
        touch ./Back_end/DailyTransactionFile.txt

        #stop and flag it if there is a diff
        

        #delete and recreate empty DailyTransactionFile
    done
done
