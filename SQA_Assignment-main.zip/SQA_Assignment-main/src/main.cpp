#include "AuctionSession.h"
#include <string>
#include <iostream>

using namespace std;

/*
This is an Auction stimulator. 
An Auction class is first run that runs the Auction.
This class listens for user arguments and peforms tasks accordingly.
Some of the tasks include: creating a user, adding an item, bidding on an item, etc.
*/

int main(int argc, char** argv) {
    int inputLength = 4;

    if (argc == inputLength) {
        //when a user logs in the currUser will be assigned. 
        cout << "Terminal is starting.." << endl; 

        // initiating sesssion
        string userAccountFileName = argv[1];
        string itemsFileName = argv[2];
        string transactionFileName = argv[3]; 
        
        AuctionSession session(userAccountFileName, itemsFileName, transactionFileName);
        session.Start();
    } else {
        cout << "Please pass the correct number of arguments" << endl;
    }


    return 0;

  
}
