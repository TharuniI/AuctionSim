#pragma once
#include <string>

using namespace std;

class Item{

    private:
        string sellerName;
        string buyerName;
        string itemName;
        string bid; 
        string remainingDays;

    public:
        //Constructor 
        Item();
        Item(string sellerName,string buyerName, string itemName, string Bid, string remainingDays);
        // Accessors
        // get username which is formatted for the backend
        string getItemFormatted() const;
        string getSellerNameFormatted() const;
        int getremainingDays() const;
        string getBuyerNameFormatted() const;
        string getBidFormatted() const;
        string getItemName() const;
        string getBuyerName() const;
        string getSellerName() const;
        double getBid() const;

        // Mutator
        void setBid(double newBid,string buyerName);
      
        
};