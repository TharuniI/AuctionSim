#pragma once
// This file will have the all the file function needed to read and write to files
#include <string>
#include <string.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm> //THARUNI 

using namespace std;

// Function used to read files
vector<string> ReadFile(string fileName){
    // Create a text string, which is used to store each line
    string line;
    vector<string> result;

    // Read from the text file
    ifstream MyReadFile("Back_end/"+fileName);

    // Use a while loop together with the getline() function to read the file line by line
    while (getline (MyReadFile, line)) {
    // Output the text from the file
    result.push_back(line);
    }

    // Close the file
    MyReadFile.close();

    return result;
}

// function used to write to files
// THIS WILL OVERWRITE THE FILE NEED TO APPEND TO THE FILE IF CREATED
void writeToFile(string fileName,string output){
    // Create and open a text file
    ofstream MyFile("Back_end/"+fileName, std::ios_base::app);

    // Write to the file
    MyFile << output;

    // Close the file
    MyFile.close();
}

// Converts backend formatting for string values to user friendly
string convertBackendString(string x){
    string result;
    int count = x.length()-1;

    while (x[count] == '_'){ count--; } 

    result = x.substr(0,count+1);
    replace(result.begin(),result.end(),'_',' ');
    return result;
}

// convert backend numeric values to it actual value as a number
double convertBackendNumericValue(string x){
    return stod(x);
}

// format string for backend add _ for spaces and to meet length
string formatString(string x,int completeLength){
    // x = deepan patel
    string result = x;
    replace(result.begin(),result.end(),' ','_');
    int currentLength = result.length();

    for(int i=0;i<completeLength-currentLength;i++){
        result += "_";
    }

    return result;
   
}

string formatIntegerValue(int x,int completeLength){
    string result = to_string(x);
    int diff_length = completeLength - result.length();
    string zeros;

    for(int i=0;i<diff_length;i++){
        zeros += "0";
    }
    return zeros + result;
}
// format numeric value for backend add 0 for placeholders
string formatNumericValue(double x,int completeLength){
    string result = to_string(x);
    int currentLength = result.length() - 4; //to_string add 6 decimal places only need 2
    result = result.substr(0,currentLength);
    string zeros;

    for(int i=0;i<completeLength-currentLength;i++){
        zeros += "0";
    }

    return zeros + result;
}