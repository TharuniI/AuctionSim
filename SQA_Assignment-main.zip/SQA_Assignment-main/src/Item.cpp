#include "Item.h"
#include <string>
#include <algorithm>
#include <iostream>

using namespace std;

string convertFormattoUnformat(string str){
    string result;
    int count = str.length()-1;

    while (str[count] == '_'){ count--; } 

    result = str.substr(0,count+1);
    replace(result.begin(),result.end(),'_',' ');
    return result;
}

string convertUnformattoFormat(string str,int completeLength){

    string result = str;
    replace(result.begin(),result.end(),' ','_');
    int currentLength = result.length();

    for(int i=0;i<completeLength-currentLength;i++){
        result += "_";
    }

    return result;
}

string NumUnformatToFormat(double x,int completeLength){
    string result = to_string(x);
    int currentLength = result.length() - 4; //to_string add 6 decimal places only need 2
    result = result.substr(0,currentLength);
    string zeros;

    for(int i=0;i<completeLength-currentLength;i++){
        zeros += "0";
    }

    return zeros + result;
}

Item::Item(){
    this->sellerName = "null";
    this->buyerName = "null";
    this->itemName = "null";
    this->bid = "null";
    this->remainingDays = "null";
}


Item::Item(string sellerName,string buyerName, string itemName, string Bid, string remainingDays){
    this->sellerName = sellerName;
    this->buyerName = buyerName;
    this->itemName = itemName;
    this->bid = Bid;
    this->remainingDays = remainingDays;
}


// Accessors
string Item::getItemFormatted() const{
    return this->itemName;
}
// Accessors
string Item::getItemName() const{
    return convertFormattoUnformat(this->itemName);
}

string Item::getSellerNameFormatted() const{
    return this->sellerName;
}
string Item::getSellerName() const{
    return convertFormattoUnformat(this->sellerName);
}

string Item::getBuyerNameFormatted() const{
    return this->buyerName;
}
string Item::getBuyerName() const{
    return convertFormattoUnformat(this->buyerName);
}

double Item::getBid() const{
    string BidFormat = this->bid;
    float BidNum = stof(BidFormat);

    return BidNum;
}

string Item::getBidFormatted() const{
    return this->bid;
}

int Item::getremainingDays() const{
    string remainingDaysFormat = this->remainingDays;
    float remainingDaysNum = stoi(remainingDaysFormat);

    return remainingDaysNum;
}

// Mutator
void Item::setBid(double newBid, string buyerName){
    this->buyerName=convertUnformattoFormat(buyerName,15);
    this->bid = NumUnformatToFormat(newBid,6);
}