#pragma once
#include "User.h"
#include "Item.h"
#include <vector>
#include <string>
#include <map>

using namespace std;

class AuctionSession{
    private:
        // User currentUser 
        User* currentUser;
        vector<User> currentAccountUsers;
        vector<string> allSessionTransactions;
        map<string, string>transactionCode;

        vector<Item> currentAuctionItems;

        //shoud be the same secret as the backend server 
        int secretKey;
        
        string userAccountFileName;
        string itemsFileName;
        string transactionFileName;

    public:
        //Constructor 
        AuctionSession(string userAccountFileName, string itemsFileName, string transactionFileName);

        // Accessors
        vector<User> getCurrentAccountUsers();
        User* getCurrentUser();
        User findUser(string inputUser);
        int findUserIndex(string username);
        Item findItem(string inputItem);
        int findItemIndex(string itemName,string sellerName);

        // Mutator
        void setCurrentUser(User* newUser);
        void addAccountUsers(User user);

        // Methods
        void Start();
        bool writeToDailyTransactionFile();
        void saveTransactionCaseOne(string transactionName,User user,double credit);
        void saveTransactionCaseTwo(string transactionName,User buyer,User seller,double refundCredit);
        void saveTransactionCaseThree(string transactionName,string itemName,User seller,string days,string minBid);
        void saveTransactionCaseFive(string transactionName,User user,double credit);
        void saveTransactionCaseFour(Item item);

        //Password
        string decrypt(string password);
        string encrypt(string password);

        // take in username and if authenticated return user obj
        void Login(User* userPoint);
        User CreateUser();
        void Logout();
        Item Advertise();
        void AddCredit();
        void Refund();
        void Bid();
        void Delete();
        void ResetPassword();
};
