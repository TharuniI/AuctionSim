#include "TransactionFunctions.h"
#include "AuctionSession.h"
#include "FileFunctions.h"
#include "User.h"
#include "Item.h"

#include <string>
#include <iostream>
#include <fstream>
#include <string>
#include <map>


using namespace std;

//Constructor 
AuctionSession::AuctionSession(string userAccountFileName, string itemsFileName, string transactionFileName) {
    this->userAccountFileName = userAccountFileName;
    this->itemsFileName = itemsFileName;
    this->transactionFileName = transactionFileName;

    this->currentUser = NULL;
    this->secretKey = 5;

    // Intializing transaction codes
    this->transactionCode["Logout"] = "00";
    this->transactionCode["Create"] = "01";
    this->transactionCode["Delete"] = "02";
    this->transactionCode["Advertise"] = "03";
    this->transactionCode["Bid"] = "04";
    this->transactionCode["Refund"] = "05";
    this->transactionCode["AddCredit"] = "06";
    this->transactionCode["ResetPassword"] = "07";
}

// Starts the Auction Session
void AuctionSession::Start() {
    string currentTransaction;
    User currUserCopy;
    // 1)Reads current user accounts File
    vector<string> currentAccountUsersFile = ReadFile(this->userAccountFileName);
    vector<string> currentAuctionItemsFile = ReadFile(this->itemsFileName);

    string line = "";
    User newUser;
    Item newItem;

    size_t usernameIndex = 0;
    int usernameLength = 15;

    size_t typeIndex = usernameIndex + usernameLength + 1;
    int typeLength = 2;
    
    size_t creditIndex = typeIndex + typeLength + 1;
    int creditLength = 9;

    size_t passwordIndex = creditIndex + creditLength + 1;
    int passwordLength = 9;
    
    // Reading each user
    for(int i=0; i<currentAccountUsersFile.size();i++){
        // Read each string input to define user vector
        line = currentAccountUsersFile[i];
        
        string currentUsername = line.substr(usernameIndex,usernameLength);
        string currentType = line.substr(typeIndex,typeLength);
        string currentCredit = line.substr(creditIndex,creditLength);

        //when reading the password we need to decrypt
        string currentPassword = line.substr(passwordIndex,passwordLength);

        // Add them to the currentAccountUsers vector as we read each user
        if(currentUsername != "END____________"){
            newUser = User(currentUsername,currentType,currentCredit,currentPassword);
            this->currentAccountUsers.push_back(newUser);
        }
    }

    size_t itemNameIndex = 0;
    int itemNameLength = 25;
    int daysLength = 3;
    
    size_t sellerNameIndex = itemNameIndex + itemNameLength + 1;
    size_t buyerNameIndex = sellerNameIndex + usernameLength + 1;
    size_t remainingDaysIndex = buyerNameIndex + usernameLength + 1;
    size_t bidIndex = remainingDaysIndex + daysLength + 1;


    // Reading each item in the auction list
    for(int i=0; i<currentAuctionItemsFile.size();i++){
        // Read each string input to define user vector
        line = currentAuctionItemsFile[i];
        // LenovoThinkPad____________TIranjan________Deepu___________084_2100.7
        string itemName = line.substr(itemNameIndex,itemNameLength);
        string sellerName = line.substr(sellerNameIndex, usernameLength);
        string buyerName = line.substr(buyerNameIndex,usernameLength);
        string remainingDays = line.substr(remainingDaysIndex,daysLength);
        string bid = line.substr(bidIndex,6); 

        if(itemName != "END______________________"){
            // sellerName,string buyerName, string itemName, string Bid, string remainingDays
            newItem = Item(sellerName, buyerName,itemName,bid,remainingDays);
            this->currentAuctionItems.push_back(newItem);
        }
    
        
    }

    // Main while loop that continuously asks the use for transaction type
    while (true) {
        cout<<"Enter transaction:" << endl;

        // Need this line to run test cases (Forces code to stop when input file reaches E)
        if(!getline(cin, currentTransaction)){
            break;
        }

        if(currentTransaction == "Login"){
            this->Login(&currUserCopy);
        }
        else if(this->getCurrentUser()!=NULL){
            if(currentTransaction == "Create"){
                this->CreateUser();
            }
            else if(currentTransaction == "Logout"){
                this->Logout();
            }else if(currentTransaction == "Advertise"){
                this->Advertise();
            }else if(currentTransaction == "AddCredit"){
                this->AddCredit();
            }else if(currentTransaction == "Refund"){
                this->Refund();
            } else if(currentTransaction == "ViewAccounts"){
                if ((*this->currentUser).getType() == "AA"){
                    for(int i=0; i<(this->currentAccountUsers.size());i++){
                        cout << this->currentAccountUsers[i].getUsername() << endl;
                    }
                } else {
                    cout << "You don't have access to do this transaction" << endl;
                }
                
            } else if(currentTransaction == "ViewItems"){
                for(int i=0; i<(this->currentAuctionItems.size());i++){
                    cout <<  "Item name: " + this->currentAuctionItems[i].getItemName() + ", Seller name: " +this->currentAuctionItems[i].getSellerName() << endl;
                }
            }
            else if(currentTransaction == "Bid"){
                this->Bid();
            }else if(currentTransaction == "Delete"){
                this->Delete();
            }
            else if(currentTransaction == "ResetPassword"){
                this->ResetPassword();
            }     
        }else{
            cout << "Please Login first!"<<"\n";
        }
    }
}

// Transaction Type: Login
// Takes username and authenticates with current username list
void AuctionSession::Login(User* userPoint) {
    
    if(this->currentUser == NULL){
        // Continue with login
        string username;
        cout << "Enter username:" << endl;
        //getline(cin,username);
        // cin.ignore();

        getline(cin, username, '\n');


        *userPoint=this->findUser(username);

        if((userPoint)->getUsername()!="null"){
            //user exist now check password

            string password;
            cout << "Enter password:" << endl;
            getline(cin, password, '\n');

            string expectedUserPassword = this->decrypt(userPoint->getPassword());
            
            if(password == expectedUserPassword){
                //if password match login successful
                setCurrentUser(userPoint);
                cout << "Login Successful!"<< endl;
            }else{
                cout << "Login Unsuccessful! Please check password again"<< endl;
            }
        }else{
            cout << "Login Unsuccessful! Username not found"<< endl;
        }

    }else{
        // There is a current user already logged in
        cout << "There is already a User Logged in. Please log out first." << endl;
    }
}

// Transaction Type: CreateUser
// Takes username and authenticates with current username list
User AuctionSession::CreateUser() {
    vector<string> userTypeList = {"AA", "FS", "BS", "SS"};

    User newUser = User();

    // get user type
    if ((*this->currentUser).getType() != "AA") {
        cout << "You do not have access to perform this transaction" << endl;
        return newUser;
    } else {
        // getting  username
        cout << "Enter new username:" << endl;
        string username;
        // cin.ignore();
        getline(cin, username, '\n');

        // check if valid username
        User isUser = this->findUser(username);

        if (isUser.getUsername() != "null") {
            cout << "This username already exists" << endl;
            return newUser;
        } else if (username.length() > 15) {
            cout << "Username must be less than 16 characters" << endl;
            return newUser;
        } else if (username == "END") {
            cout << "Cannot name user END" << endl;
             return newUser;
        }
      
        // getting valid user type
        string userType;
        cout << "Enter user type:" << endl;
        getline(cin, userType,'\n');
    
        if (find(userTypeList.begin(), userTypeList.end(), userType) == userTypeList.end()){
            cout << "Invalid User Type" << endl;          
            return newUser;
        }
        
        string password;
        //need to check if password is only 9 character long
        cout << "Enter user password:" << endl;
        getline(cin, password);
        if (password.length() != 9){
            cout << "Password must be 9 characters long" << endl;
            return newUser;
        }


        string encryptedPassword = this->encrypt(password);

        // save transaction before returning user
        string defaultCredit = "0.00";
        newUser = User(formatString(username,15),userType,defaultCredit,encryptedPassword);
        this->addAccountUsers(newUser);
        saveTransactionCaseFive("Create",newUser,stod(defaultCredit));

        cout << "Create Successful!"<< endl;

    }

    return newUser;
}

// Transaction Type: Logout
// Takes username and authenticates with current username list
void AuctionSession::Logout() {


    // write out the daily transaction file
    if(this->getCurrentUser()!=NULL){
        allSessionTransactions.push_back("00\n");
        writeToDailyTransactionFile();
        this->setCurrentUser(NULL);
        this->allSessionTransactions.clear();
        cout<< "Logout Successful!" << endl;
        exit(0);
    }
    else{
        cout<< "Please Login first!"<< endl;
    }

    
}

// Transaction Type: AddCredit
void AuctionSession::AddCredit() {
    string username;
    // if admin ask for username
    if ((*this->currentUser).getType() == "AA"){
        cout << "Enter username of an account you want to add credit to:" << endl;
        // cin.ignore();
        getline(cin, username, '\n');

        User isUser = this->findUser(username);
        if (isUser.getUsername() == "null" ){ cout << "This username does not exist" << endl; }
    } else { username = (*this->currentUser).getUsername(); }
    
    User isUser = this->findUser(username);
    if (isUser.getUsername() != "null") {
        // get valid credit amount
        cout << "Enter the amount of credit to add:" << endl;
        string credit;
        getline(cin, credit);

        double creditDoubleVar= stod(credit);

        if (creditDoubleVar < 1000.00) {
            if (creditDoubleVar > 0.00) {
                // save information
                int userIndex=this->findUserIndex(username);
                double currentCredit=(this->currentAccountUsers[userIndex]).getAvailableCredit();
                (this->currentAccountUsers[userIndex]).setAvailableCredit(creditDoubleVar+currentCredit);
                this->saveTransactionCaseOne("AddCredit",this->currentAccountUsers[userIndex],creditDoubleVar+currentCredit);
                cout<<"AddCredit Successful!"<< endl;
            } else {
                cout << "Must have a positive credit amount" << endl;
            }
        } else {
            cout << "Can not enter more than $1000 to an account in a given session" << endl;
        }
    }
}

// Transaction Type: Refund
void AuctionSession::Refund(){
    if ((*this->currentUser).getType() != "AA"){
        cout << "You do not have access to perform this transaction" << endl;
    } else {
        //get first user
        int sellerIndex=-1;
        string sellerUsername;
        cout << "Enter username of the seller's account: "<< endl;
        // cin.ignore();
        getline(cin, sellerUsername, '\n');
        sellerIndex=this->findUserIndex(sellerUsername);
        if(sellerIndex==-1){
            cout<<"Buyer is not found."<<endl;
            return;

        }

        //get second user
        int buyerIndex=-1;
        string buyerUsername;
        cout << "Enter username of the buyer's account: "<< endl;
        getline(cin, buyerUsername, '\n');
        buyerIndex=this->findUserIndex(buyerUsername);
        if(buyerIndex==-1){
            cout<<"Buyer is not found."<<endl;
            return;
        }
        
        //get credit amount
        string creditString;
        double creditDouble;
        
        cout << "Enter the credit amount to refund from the seller to the buyer: "<< endl;
        getline(cin, creditString, '\n');
        creditDouble=stod(creditString);


        // check if users exist and amount is available
        if(this->currentAccountUsers[sellerIndex].getAvailableCredit()>=creditDouble){
            //calculate new credit for both users
            double newSellerCredit=this->currentAccountUsers[sellerIndex].getAvailableCredit()-creditDouble;
            double newBuyerCredit=this->currentAccountUsers[buyerIndex].getAvailableCredit()+creditDouble;

            //set new credit to both users
            currentAccountUsers[sellerIndex].setAvailableCredit(newSellerCredit);
            currentAccountUsers[buyerIndex].setAvailableCredit(newBuyerCredit);

            
            this->saveTransactionCaseTwo("Refund",currentAccountUsers[buyerIndex], currentAccountUsers[sellerIndex],creditDouble);
            cout << "Refund Successful!"<< endl;
        }else{
            cout << "Seller does not have enough credits."<< endl;
            return;
        }
    }
}

// Transaction Type: Bid
void AuctionSession::Bid(){
    if ((*this->currentUser).getType() == "SS"){
        cout << "You do not have access to perform this transaction" << endl;
    } else {

    
    //get item name
    string itemName;
    cout << "Enter item name: "<< endl;
    // cin.ignore();
    getline(cin, itemName, '\n');

    //get seller username
    string itemSellerUsername;
    cout << "Enter the username of this item's Seller: "<< endl;
    getline(cin, itemSellerUsername, '\n');

    //get itemindex (match both item name AND username)
    int itemIndex=-1;
    itemIndex=this->findItemIndex(itemName,itemSellerUsername);
    if(itemIndex==-1){
        cout<<"Item not found. Please enter an existing item’s name."<< endl;
        return;
    }


    //get bid amount
    string bidString;
    double bidDouble;
    
    cout << "Enter bid amount: "<< endl;
    getline(cin, bidString, '\n');
    bidDouble=stod(bidString);
    
    if(bidDouble<=this->currentAuctionItems[itemIndex].getBid()){
        cout<<"Your bid has to be higher than the current highest bid."<< endl;
        return;
    }



    //validate that item index not -1 and bid amount is 5% higher than currentHighest
    double fivePercentOfMaxBid;
    
    fivePercentOfMaxBid=this->currentAuctionItems[itemIndex].getBid()*1.05;

    if(bidDouble>=fivePercentOfMaxBid){
        //edit buyerUsername and bid
        this->currentAuctionItems[itemIndex].setBid(bidDouble,currentUser->getUsername());
    }else{
        cout<<"Your bid has to be at least 5 percent higher than the current highest bid."<<endl;
        return;
    }

    saveTransactionCaseFour(this->currentAuctionItems[itemIndex]);
    cout<<"Bid Successful!"<< endl;
    }

}

// Transaction Type: Delete User
void AuctionSession::Delete(){
    if ((*this->currentUser).getType() != "AA"){
        cout << "You do not have access to perform this transaction" << endl;
    } else {
        string deleteUsername;
        cout << "Enter username of account to delete:" << endl;
        getline(cin, deleteUsername, '\n');

        if ((*this->currentUser).getUsername() == deleteUsername) {
            cout << "Users cannot delete themselves" << endl;
        } else {

            int deleteIndex=-1;
            // Find user index to delete
            for(int i=0;i< this->currentAccountUsers.size();i++){
                if(this->currentAccountUsers[i].getUsername()==deleteUsername){
                    deleteIndex=i;
                }
            }

            if(deleteIndex!=-1){
                User deletedUser;
                deletedUser=this->currentAccountUsers[deleteIndex];
                
                this->currentAccountUsers.erase(this->currentAccountUsers.begin()+deleteIndex);

                //delete all items that have that user as creater
                vector<int> deleteItemIndices;
                for(int i=0; i<(this->currentAuctionItems.size());i++){
                    if(this->currentAuctionItems[i].getSellerName()==deleteUsername){
                        deleteItemIndices.push_back(i);
                    }
                }
                for(int i=0; i<(deleteItemIndices.size());i++){
                    this->currentAuctionItems.erase(this->currentAuctionItems.begin()+deleteItemIndices[i]);
                }
                saveTransactionCaseOne("Delete",deletedUser,deletedUser.getAvailableCredit());
                cout<<"Successfully deleted user!"<< endl;
            }else{
                cout<<"Could not find username"<< endl;
            }
        }
    }
}

// Transaction Type: Advertise
// Takes username and authenticates with current username list
Item AuctionSession::Advertise() {
    //initialize
    string sellerName = (*this->currentUser).getUsername(); //get username
    string buyerName = "null";
    string itemName = "null";
    string bid ="00.00"; 
    string remainingDays = "0";
    
    Item newItem = Item(sellerName, buyerName, itemName, bid, remainingDays);

    // get user type
    if ((*this->currentUser).getType() == "BS") {
        cout << "You do not have access to perform this transaction" << endl;
        return newItem;
    } else {
        //item name
        cout << "Enter item name:"<<endl;
        
        getline(cin, itemName);

        Item isItem = this->findItem(itemName);
        // check valid item name
        if (isItem.getItemName() != "null" ){
            cout << "This item name already exists" << endl;
            return newItem;
        } else if (itemName == "END" ){
            cout << "Cannot name item END" << endl;
            return newItem;
        } else if (itemName.length() > 25){
            cout << "Item name must be less than 26 characters" << endl;
            return newItem;
        }

        //bid amount
        cout << "Enter minimum bid amount:" << endl;
        getline(cin, bid);

        // check valid bid value
        if (stod(bid) < 0) {
            cout << "Must have a positive bid amount" << endl;
            return newItem;
        } else if (stod(bid) > 999.99) {
            cout << "Bid amount should be less than $999.99" << endl;
            return newItem;
        }
            
        //number of auction days
        cout << "Enter max days for auction:" << endl;
        getline(cin, remainingDays);

        if (stoi(remainingDays) > 100) {
            cout << "Auction length can't be greater than 100 days" << endl;
            return newItem;
        } else if (stoi(remainingDays) <= 0){
            cout << "Auction length must be greater than zero" << endl;
            return newItem;
        }
            
        // We need to format all the value to be backend specific
        sellerName = formatString(sellerName,15);
        buyerName = formatString(buyerName,15);
        itemName = formatString(itemName,25);
        bid = formatNumericValue(stod(bid),6);
        remainingDays = formatIntegerValue(stoi(remainingDays),3);
        newItem = Item(sellerName, buyerName, itemName, bid, remainingDays);

        this->currentAuctionItems.push_back(newItem);

        this->saveTransactionCaseThree("Advertise",itemName, *this->currentUser,remainingDays,bid);
        cout << "Advertise Successful!" << endl;
    }
    return newItem;
}

void AuctionSession::ResetPassword(){
    string password;
    User currentUser = User();
    //need to check if password is only 9 character long
    cout << "Enter new password:" << endl;
    getline(cin, password);

    if (password.length() != 9){
        cout << "New password must be 9 characters long" << endl;
        return;
    }else{
        string newEncryptedPassword = this->encrypt(password);
        currentUser = User(formatString(this->currentUser->getUsername(),15),this->currentUser->getType(),to_string(this->currentUser->getAvailableCredit()),newEncryptedPassword);
        saveTransactionCaseFive("ResetPassword",currentUser,this->currentUser->getAvailableCredit());
        cout << "Reset Password Successful!"<< endl;
        return;
    }

}