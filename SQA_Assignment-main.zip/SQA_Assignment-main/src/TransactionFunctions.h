#pragma once
#include "AuctionSession.h"
#include "FileFunctions.h"
#include "User.h"
#include "Item.h"

#include <string>
#include <string.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <map>

// Accessors
vector<User> AuctionSession::getCurrentAccountUsers(){ return this->currentAccountUsers;}

// Mutator
void AuctionSession::setCurrentUser(User* newUser){ this->currentUser = newUser; }
User* AuctionSession::getCurrentUser() { return this->currentUser; }

//Methods

//Encrypts the password 
string AuctionSession::encrypt(string password){
    string encryptedPassword;
    int temp; //encrpted int value of the character

    for(int i=0;i<password.length();i++){
        char currentChar = (char)password[i];
        temp = (int)currentChar - this->secretKey;
        encryptedPassword += (char)temp;
    }

    return encryptedPassword;
}

// Decrypts the password
string AuctionSession::decrypt(string password){
    string decryptedPassword;
    int temp; //encrpted int value of the character

    for(int i=0;i<password.length();i++){
        char currentChar = (char)password[i];
        temp = (int)currentChar + this->secretKey;
        decryptedPassword += (char)temp;
    }

    return decryptedPassword;
}

// Add user to user account vector
void AuctionSession::addAccountUsers(User user){
    this->currentAccountUsers.push_back(user);
}

// Find user in user account list
User AuctionSession::findUser(string username){
    for(int i=0;i<(this->currentAccountUsers).size();i++){
        if(this->currentAccountUsers[i].getUsername() ==  username) {
            return currentAccountUsers[i];
        }
    }
    return User();
}

// Find item in items list
Item AuctionSession::findItem(string itemname){
    for(int i=0;i<(this->currentAuctionItems).size();i++){
        if(this->currentAuctionItems[i].getItemName() ==  itemname) {
            return currentAuctionItems[i];
        }
    }
    return Item();
}

// Find index of username in a list
int AuctionSession::findUserIndex(string username){
    for(int i=0;i<(this->currentAccountUsers).size();i++){
        if(this->currentAccountUsers[i].getUsername() ==  username) {
            return i;
        }
    }
    return -1;
}

// Find index of item name in a list
int AuctionSession::findItemIndex(string itemName,string sellerName){
    for(int i=0;i<(this->currentAuctionItems).size();i++){
        if(this->currentAuctionItems[i].getItemName() ==  itemName && this->currentAuctionItems[i].getSellerName()==sellerName) {
            return i;
        }
    }
    return -1;
}


// All Specific Methods used for: writing to dailyTransaction File
// this fucntion is used to record 02-delete, 06-addcredit, 00-end of session to the daily transacton file
void AuctionSession::saveTransactionCaseOne(string transactionName,User user,double credit){
    string transactionVal = this->transactionCode[transactionName];
    string creditVal = formatNumericValue(credit,9);
    string line = transactionVal + "_" + user.getUsernameFormatted() + "_" + user.getType() + "_" + creditVal+"\n";
    allSessionTransactions.push_back(line);
}

// this fucntion is used to record 05-refund to the daily transacton file
void AuctionSession::saveTransactionCaseTwo(string transactionName,User buyer,User seller,double refundCredit){
    string transactionVal = this->transactionCode[transactionName];
    string refundCreditVal = formatNumericValue(refundCredit,9);
    string line = transactionVal + "_" + buyer.getUsernameFormatted() + "_" + seller.getUsernameFormatted() + "_" + refundCreditVal+"\n";
    allSessionTransactions.push_back(line);
}

// this fucntion is used to record 03-advertise to the daily transacton file
void AuctionSession::saveTransactionCaseThree(string transactionName,string itemName,User seller,string days,string minBid){
    string transactionVal = this->transactionCode[transactionName];
    string line = this->transactionCode["Advertise"]+"_" +itemName+"_" +seller.getUsernameFormatted()+"_" +days+"_" +minBid+"\n";
    allSessionTransactions.push_back(line);
}

// this fucntion is used to record 04-bid to the daily transacton file
void AuctionSession::saveTransactionCaseFour(Item item){
    string line = this->transactionCode["Bid"]+ "_" +item.getItemFormatted()+ "_" + item.getSellerNameFormatted()+ "_" + item.getBuyerNameFormatted()+ "_" +item.getBidFormatted()+"\n";
    allSessionTransactions.push_back(line);
}

// this fucntion is used to record 01-create
void AuctionSession::saveTransactionCaseFive(string transactionName,User user,double credit){
    string transactionVal = this->transactionCode[transactionName];
    string creditVal = formatNumericValue(credit,9);
    string line = transactionVal + "_" + user.getUsernameFormatted() + "_" + user.getType() + "_" + creditVal+ "_" + user.getPassword() + "\n";
    allSessionTransactions.push_back(line);
}

bool AuctionSession::writeToDailyTransactionFile() {
    for(int i=0;i< this->allSessionTransactions.size();i++){
        writeToFile(this->transactionFileName,this->allSessionTransactions[i]);
    }
    return true;
}