#pragma once
#include <string>

using namespace std;

class User{
    private:
        string username;
        // AA=admin, FS=full-standard, BS=buy-standard, SS=sell-standard)
        string type;
        string availableCredit; 
        string password;

    public:
        //Constructor 
        
        User();
        User(string username,string type);
        User(string username,string type,string availableCredit,string password);

        // Accessors
        // get username which is formatted for the backend
        string getUsernameFormatted() const;
        string getUsername() const;
        string getPassword() const;
        string getType() const;
        double getAvailableCredit() const;
        string decrypt(string password);
        

        // Mutator
        void setAvailableCredit(double newAvailableCredit);
        void encrypt(string password);
};