#include "User.h"
#include <string>
#include <algorithm>
#include <iostream>


using namespace std;

User::User(){
    this->username = "null";
    this->type = "null";
    this->availableCredit = "null";
    this->password = "null"; 
}

User::User(string username,string type){
    this->username = username;
    this->type = type;
    this->availableCredit = "null";
}

User::User(string username,string type,string availableCredit,string password){
    this->username = username;
    this->type = type;
    this->availableCredit = availableCredit;
    this->password = password;
}

// Accessors

string User::getUsernameFormatted() const{
    return this->username;
}

string User::getPassword() const{
    return this->password;
}

// removes extra underscores and replaces underscores within the username with spaces 
string User::getUsername() const{
    string username_format = this->username;
    int count = username_format.length()-1;

    while (username_format[count] == '_'){ count--; }

    string username_unformat = username_format.substr(0,count+1);
    replace(username_unformat.begin(),username_unformat.end(),'_',' ');

    return username_unformat;
}

string User::getType() const{
    return this->type;
}

double User::getAvailableCredit() const{
    string credit_format = this->availableCredit;
    double credit_num = stod(credit_format);
    return credit_num;
}

// Mutator
void User::setAvailableCredit(double newAvailableCredit){
    this->availableCredit = to_string(newAvailableCredit);
}

